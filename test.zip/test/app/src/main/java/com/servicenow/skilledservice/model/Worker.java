package com.servicenow.skilledservice.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import static  com.servicenow.skilledservice.database.workers.WorkersDAO.WORKERS_TABLE;

@Entity(tableName = WORKERS_TABLE)
public class Worker {
    @PrimaryKey
    private int id;
    private String name;

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public void setRatings(long ratings) {
        this.ratings = ratings;
    }

    private String specialization;
    private long ratings;

    public Worker(int id , String name, String specialization , long rating){
        this.id = id;
        this.name = name;
        this.specialization = specialization;
        this.ratings = rating;
    }

    public  Worker(){

    }
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSpecialization() {
        return specialization;
    }

    public long getRatings() {
        return ratings;
    }



}
