package com.servicenow.skilledservice.viewmodel.RequestWork;

import android.app.Application;

import com.servicenow.skilledservice.database.WorkersRepository;
import com.servicenow.skilledservice.model.Worker;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

public class RequestWorkViewModel extends AndroidViewModel {
    private WorkersRepository workersRepository;
    public RequestWorkViewModel(@NonNull Application application) {
        super(application);
         workersRepository = new WorkersRepository(application);
    }

    public LiveData<List<Worker>> getWorkersData(){
        return workersRepository.getWorkersData();
    }


}
