package com.servicenow.skilledservice.view.RequestWork.Activities;

import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuInflater;

import com.servicenow.skilledservice.model.Worker;
import com.servicenow.skilledservice.view.RequestWork.Adapters.RequestWorkAdapter;
import com.servicenow.skilledservice.viewmodel.RequestWork.RequestWorkViewModel;

import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import skilledservice.servicenow.com.R;

public class RequestWorkActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.requestwork);
        final RecyclerView workersListView = findViewById(R.id.workers_list);
        workersListView.setLayoutManager(new LinearLayoutManager(this));
        workersListView.setHasFixedSize(true);

        final RequestWorkAdapter adapter = new RequestWorkAdapter(this);
        workersListView.setAdapter(adapter);

        RequestWorkViewModel requestWorkViewModel = ViewModelProviders.of(this).get(RequestWorkViewModel.class);
        requestWorkViewModel.getWorkersData().observe(this, new Observer<List<Worker>>() {
            @Override
            public void onChanged(List<Worker> workers) {
                    if(workers == null || workers.isEmpty()){
                        adapter.setData(workers);
                    }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.app_bar_search));

        searchView.setSubmitButtonEnabled(true);
        searchView.setOnQueryTextListener(onQueryTextListener);
        searchView.setIconifiedByDefault(false);
        searchView.setQueryHint(getString(R.string.search_hint));
        return super.onCreateOptionsMenu(menu);


    }

    private SearchView.OnQueryTextListener onQueryTextListener = new SearchView.OnQueryTextListener() {
        @Override
        public boolean onQueryTextSubmit(String s) {
            return false;
        }

        @Override
        public boolean onQueryTextChange(String s) {
            return false;
        }
    };
}
