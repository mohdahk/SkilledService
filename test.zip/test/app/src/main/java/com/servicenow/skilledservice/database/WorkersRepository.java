package com.servicenow.skilledservice.database;

import android.app.Application;

import com.servicenow.skilledservice.database.workers.WorkersDAO;
import com.servicenow.skilledservice.database.workers.WorkersDB;
import com.servicenow.skilledservice.model.Worker;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.room.Insert;

import static androidx.room.OnConflictStrategy.REPLACE;

public class WorkersRepository {
    private final WorkersDAO workersDAO;
    private final Executor executor;

    public WorkersRepository(Application application) {
        WorkersDB database = WorkersDB.getInstance(application);
        workersDAO = database.workersDAO();

        // Executor to run the service request in background thread
        executor = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<Worker>> getWorkersData() {
        loadDataToWorkersDB();
        return workersDAO.getWorkersData();
    }

    private void loadDataToWorkersDB(){

        executor.execute(new Runnable() {
            @Override
            public void run() {

                   workersDAO.insert(getSampleWorkersData());
            }
        });
    }

    private List<Worker> getSampleWorkersData(){
        List<Worker> workers = new ArrayList<Worker>();
        workers.add(new Worker(1,"James Butt","Carpenter",3));
        workers.add(new Worker(2,"Art Venere","Carpenter",3));
        workers.add(new Worker(1,"Donette Foller","Plumber",1));
        workers.add(new Worker(1,"Leota Dilliard","Plumber",2));
        return workers;
    }
}
