package com.servicenow.skilledservice.view.RequestWork.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.servicenow.skilledservice.model.Worker;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;
import skilledservice.servicenow.com.R;

public class RequestWorkAdapter extends RecyclerView.Adapter<RequestWorkAdapter.WorkerViewHolder> {

    private Context context;
    private List<Worker> workerList = new ArrayList<>();

    public RequestWorkAdapter(Context context){
        this.context = context;
    }
    @NonNull
    @Override
    public WorkerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.workerlistitem, parent, false);
        return new WorkerViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkerViewHolder holder, int position) {
            Worker worker = workerList.get(position);
            holder.tvWokersName.setText(worker.getName());
            holder.tvRatings.setText(worker.getName());
            holder.tvWorkersSpecialization.setText(worker.getSpecialization());
    }

    @Override
    public int getItemCount() {
        return workerList.size();
    }

    public void setData(List<Worker> workerList) {
        this.workerList = workerList;
        notifyDataSetChanged();
    }

    class WorkerViewHolder extends RecyclerView.ViewHolder {

        TextView tvWokersName;
        TextView tvWorkersSpecialization;
        TextView tvRatings;

        private WorkerViewHolder(View itemView) {
            super(itemView);

            tvWokersName = itemView.findViewById(R.id.worker_name);
            tvWorkersSpecialization = itemView.findViewById(R.id.worker_specialization);
            tvRatings = itemView.findViewById(R.id.worker_ratings);

        }
    }
}
